<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS - Customers Page</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .navbar {
        background-color: #333;
        overflow: hidden;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    .success {
        color: green;
    }
    .navbar form {
        float: left;
        margin: 0;
    }

    .navbar button {
        background: none;
        border: none;
        color: white;
        font-size: inherit;
        font-family: inherit;
        padding: 14px 16px;
        cursor: pointer;
    }

    .navbar button:hover {
        background-color: #ddd;
        color: black;
    }
</style>
<body>
    <div class="navbar">
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/customers">Customers</a>
        <a href="/users">Users</a>
        @auth
            <a href="{{ route('dashboard') }}">Dashboard</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit">Logout ({{ Auth::user()->username }})</button>
            </form>
        @else
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
        @endauth
    </div>
    <h1>Customers</h1>
    @if (session('success'))
        <p class="success">{{ session('success') }}</p>
    @endif

    <p><a href="/customers/create">+ Add Customer</a></p>

    <table>
        <thead>
            <tr>
                <th>Profile Picture</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($customers as $c)
                <tr>
                    <td>
                        @if (!empty($c['avatar']))
                            <img src="{{ asset('storage/customers/' . $c['avatar']) }}" alt="Profile Picture" width="50" height="50">
                        @else
                            <img src="{{ asset('images/defaultswag.jpg') }}" alt="No Profile Picture" width="50" height="50">
                        @endif
                    </td>
                    <td>{{ $c['full_name'] }}</td>
                    <td>{{ $c['email'] }}</td>
                    <td>{{ $c['phone'] }}</td>
                    <td>{{ $c['created_at'] }}</td>
                    <td>
                        <a href="{{ route('customers.edit', $c['id']) }}">Edit</a>
                    </td>
                </tr>
            @empty
                <tr><td colspan="6">No customers found.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>
