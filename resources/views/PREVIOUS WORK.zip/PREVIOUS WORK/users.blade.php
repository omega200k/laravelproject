<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS - User Accounts Page</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .navbar {
        background-color: #333;
        overflow: hidden;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }

    .success {
        color: green;
    }
    .navbar form {
        float: left;
        margin: 0;
    }

    .navbar button {
        background: none;
        border: none;
        color: white;
        font-size: inherit;
        font-family: inherit;
        padding: 14px 16px;
        cursor: pointer;
    }

    .navbar button:hover {
        background-color: #ddd;
        color: black;
    }
</style>
<body>
    <div class="navbar">
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/customers">Customers</a>
        <a href="/users">Users</a>
        @auth
            <a href="{{ route('dashboard') }}">Dashboard</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit">Logout ({{ Auth::user()->username }})</button>
            </form>
        @else
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
        @endauth
    </div>
    <h1>User Accounts</h1>
    @if (session('error'))
        <p style="color: red;">{{ session('error') }}</p>
    @endif

    @if (session('success'))
        <p class="success">{{ session('success') }}</p>
    @endif

    <p><a href="/users/create">+ Add User</a></p>

    <table>
        <thead>
            <tr>
                <th>Profile Picture</th>
                <th>Username</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Created At</th>
                <th>Edit Profile</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($users as $u)
                <tr>
                    <td>
                        @if (!empty($u['avatar']))
                            <img src="{{ asset('storage/avatars/' . $u['avatar']) }}" alt="Profile Picture" width="50" height="50">
                        @else
                            <img src="{{ asset('images/defaultswag.jpg') }}" alt="No Profile Picture" width="50" height="50">
                        @endif
                    </td>
                    <td>{{ $u['username'] }}</td>
                    <td>{{ $u['full_name'] }}</td>
                    <td>{{ $u['email'] }}</td>
                    <td>{{ $u['user_role'] }}</td>
                    <td>{{ $u['created_at'] }}</td>
                    <td>
                        <a href="{{ route('users.edit', $u['id']) }}">Edit</a>
                    </td>
                </tr>
            @empty
                <tr><td colspan="7">No users found.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>
