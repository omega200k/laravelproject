<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS - Edit User Page</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .navbar {
        background-color: #333;
        overflow: hidden;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
    .customer_form {
        max-width: 400px;
    }
    input[type="text"], input[type="email"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    select {
        width: 250px;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .error_list {
        color: red;
    }
    .success {
        color: green;
    }
    .navbar form {
        float: left;
        margin: 0;
    }

    .navbar button {
        background: none;
        border: none;
        color: white;
        font-size: inherit;
        font-family: inherit;
        padding: 14px 16px;
        cursor: pointer;
    }

    .navbar button:hover {
        background-color: #ddd;
        color: black;
    }
</style>
<body>
    <div class="navbar">
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/customers">Customers</a>
        <a href="/users">Users</a>
        @auth
            <a href="{{ route('dashboard') }}">Dashboard</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit">Logout ({{ Auth::user()->username }})</button>
            </form>
        @else
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
        @endauth
    </div>
    <h1>Edit User</h1>
    @if ($errors->any())
        <ul class="error_list">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif
    <form action="{{ route('users.update', $user['id']) }}" class="customer_form" method="post" enctype="multipart/form-data" novalidate>
        @csrf
        @method('PUT')
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="{{ old('username', $user['username']) }}"><br><br>

        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" value="{{ old('full_name', $user['full_name']) }}"><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ old('email', $user['email']) }}"><br><br>

        <label for="user_role">User Role:</label>
        <select name="user_role" id="user_role">
            <option value="Admin" {{ old('user_role', $user['user_role']) === 'Admin' ? 'selected' : '' }}>Admin</option>
            <option value="User" {{ old('user_role', $user['user_role']) === 'User' ? 'selected' : '' }}>User</option>
        </select><br><br>

        <label for="password">New Password (leave blank to keep current):</label>
        <input type="password" id="password" name="password"><br><br>

        <label for="password_confirmation">Confirm New Password:</label>
        <input type="password" id="password_confirmation" name="password_confirmation"><br><br>

        <label>Current Profile Picture:</label><br>
        @if (!empty($user['avatar']))
            <img src="{{ asset('storage/avatars/' . $user['avatar']) }}" alt="Profile Picture" width="100" height="100">
        @else
            <img src="{{ asset('images/placeholder.svg') }}" alt="No Profile Picture" width="100" height="100">
        @endif
        <br><br>

        <label for="avatar">Profile Picture:</label>
        <input type="file" id="avatar" name="avatar" accept="image/jpg,image/jpeg,image/png"><br><br>

        <input type="submit" value="Update User">
    </form>
</body>
</html>
