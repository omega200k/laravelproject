<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Page</title>
</head>
<style>
 nav {
        background-color: #f0f0f0;
        padding: 10px;
    }

    nav a {
        margin-right: 10px;
        text-decoration: none;
        color: #333;
    }
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
</style>
<body>
    <nav>
        <a href="/"> Home </a> |
        <a href="/about"> About </a> |
        <a href="/customer"> Customer </a> |
        <a href="/user"> User </a>
    </nav>
    <hr>

    <h1>User</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Username</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $u)
                <tr>
                    <td>{{ $u['id'] }}</td>
                    <td>{{ $u['full_name'] }}</td>
                    <td>{{ $u['username'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
