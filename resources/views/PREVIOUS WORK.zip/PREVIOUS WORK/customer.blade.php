<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Page</title>
</head>
<style>
    nav {
        background-color: #f0f0f0;
        padding: 10px;
    }

    nav a {
        margin-right: 10px;
        text-decoration: none;
        color: #333;
    }
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
</style>
<body>
    <nav>
        <a href="/"> Home </a> |
        <a href="/about"> About </a> |
        <a href="/customer"> Customer </a> |
        <a href="/user"> User </a>
    </nav>
    <hr>
    <h1>Customer</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Full Name</th>
                <th>Email</th>
                <th>Phone</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($customers as $c)
                <tr>
                    <td>{{ $c['id'] }}</td>
                    <td>{{ $c['full_name'] }}</td>
                    <td>{{ $c['email'] }}</td>
                    <td>{{ $c['phone'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>