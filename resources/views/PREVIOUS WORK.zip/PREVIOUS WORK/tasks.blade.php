<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tasks - Task List Page</title>
</head>
<style>
    nav {
        background-color: #f0f0f0;
        padding: 10px;
    }

    nav a {
        margin-right: 10px;
        text-decoration: none;
        color: #333;
    }
    table {
        border-collapse: collapse;
        width: 100%;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }
    .circle_pending {
        width: 20px;
        height: 20px;
        background-color: red;
        border-radius: 50%;
        display: inline-block;
    }
    .circle_finished {
        width: 20px;
        height: 20px;
        background-color: green;
        border-radius: 50%;
        display: inline-block;
    }
</style>
<body>
    <nav>
        <a href="/"> Home </a> |
        <a href="/tasks"> Task List </a> |
        <a href="/profile"> Profile </a> |
        <a href="/about"> About </a>
    </nav>
    <hr>

    <h1>Task List</h1>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Status</th>
                <th>Task Date</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($tasks as $t)
                <tr>
                    <td>{{ $t['id'] }}</td>
                    <td>{{ $t['title'] }}</td>
                    <td>
                        @if (strtolower($t['status']) === 'pending')
                            {{ ucfirst($t['status']) }} <span class="circle_pending"></span>
                        @elseif (strtolower($t['status']) === 'finished')
                            {{ ucfirst($t['status']) }} <span class="circle_finished"></span>
                        @else
                            {{ ucfirst($t['status']) }}
                        @endif
                    </td>
                    <td>{{ $t['task_date'] }}</td>
                    <td>{{ $t['created_at'] }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>
