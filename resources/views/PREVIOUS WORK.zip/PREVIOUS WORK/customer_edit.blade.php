<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS - Edit Customer Page</title>
</head>
<style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    .navbar {
        background-color: #333;
        overflow: hidden;
    }

    .navbar a {
        float: left;
        display: block;
        color: white;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
    }

    .navbar a:hover {
        background-color: #ddd;
        color: black;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
    .customer_form {
        max-width: 400px;
    }
    input[type="text"], input[type="email"] {
        width: 100%;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    select {
        width: 250px;
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
    }
    .error_list {
        color: red;
    }
    .success {
        color: green;
    }
    .navbar form {
        float: left;
        margin: 0;
    }

    .navbar button {
        background: none;
        border: none;
        color: white;
        font-size: inherit;
        font-family: inherit;
        padding: 14px 16px;
        cursor: pointer;
    }

    .navbar button:hover {
        background-color: #ddd;
        color: black;
    }
</style>
<body>
    <div class="navbar">
        <a href="/">Home</a>
        <a href="/about">About</a>
        <a href="/customers">Customers</a>
        <a href="/users">Users</a>
        @auth
            <a href="{{ route('dashboard') }}">Dashboard</a>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit">Logout ({{ Auth::user()->username }})</button>
            </form>
        @else
            <a href="{{ route('login') }}">Login</a>
            <a href="{{ route('register') }}">Register</a>
        @endauth
    </div>
    <h1>Edit Customer</h1>
    @if ($errors->any())
        <ul class="error_list">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif
    <form action="{{ route('customers.update', $customer['id']) }}" class="customer_form" method="post" novalidate>
        @csrf
        @method('PUT')
        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" value="{{ old('full_name', $customer['full_name']) }}"><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="{{ old('email', $customer['email']) }}"><br><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="{{ old('phone', $customer['phone']) }}"><br><br>

        <input type="submit" value="Update Customer">
    </form>
</body>
</html>
